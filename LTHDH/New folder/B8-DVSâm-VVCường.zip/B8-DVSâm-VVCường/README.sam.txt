﻿File chứa source code là file: finalpipe.c
Code chạy trên nền Linux (gốc ở Ubuntu 18.04) sử dụng GCC để compile.

dangvansam98@gmail.com