//CHUONG TRINH GIAO TIEP 2 PROCESS BANG PIPE
//DANG VAN SAM- 16150196
//KTPM12
//HVKTQS MTA 2018
#include <stdio.h> 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>
#define BUFFER_SIZE 200
#define FOR(a, b) for (a = 0; a < b; a++)
//swap funtion
void swap(int * a, int * b) {
    int c = * a;
    * a = * b;
    * b = c;
}
//sort funtion
void bubbleSort(int a[], int n) {
    int i, j;
    FOR(i, n)
    FOR(j, n)
    if (a[i] < a[j])
        swap( & a[i], & a[j]);
}
//write to file funtion
void write2file(int a[], int n) {
    FILE * f;
    f = fopen("ouput.txt", "wt");
    for (int i = 0; i < n; i++)
        fprintf(f, "%d ", a[i]);
    fclose(f);
}
//transfer data between p0 &p1
void byPipe(int n, int data[]) {
    int i, status;
    int a[20];
    int P1pipe[2];
    int P0pipe[2];
    char buffer[11] = {
        0
    };
    char ACK;
    if (pipe(P1pipe) < 0 || pipe(P0pipe) < 0) { //creating pipes to communicate
        printf("Error in creating pipes\n");
        exit(0);
    }
    pid_t P1PID = fork(); //forking the process
    if (P1PID < 0) {
        printf("Error in forking not enough memory\n");
        exit(0);
    }
    if (P1PID > 0) { //P0 process
        //printf("Sending data to P1...\n\n");
        FOR(i, n) {
            snprintf(buffer, sizeof(buffer), "%d", data[i]); //convert integer to string
            printf("P0 : Writing to P1pipe data=%s waiting ACK\n", buffer);
            sleep(1);
            write(P1pipe[1], buffer, strlen(buffer)); //write integer to pipe
            read(P0pipe[0], & ACK, 1); //wait for ACKnowledgement
            printf("P0 : ACK received!\n\n");
            sleep(1);
        }
        FOR(i, n) {
            printf("P0 : Reading from P0pipe ");
            sleep(1);
            read(P0pipe[0], buffer, 11);
            a[i] = atoi(buffer);
            printf("data=%d ACK sent!\n", a[i]);
            sleep(1);
            write(P1pipe[1], "1", 1);
        }
        close(P1pipe[0]);
        close(P1pipe[1]);
        wait( &status);

    } else { //the P1 process
        //printf("Sending data back P0...\n");
        FOR(i, n) {
            printf("P1 : Reading from P1pipe ");
            sleep(1);
            read(P1pipe[0], buffer, 11);
            a[i] = atoi(buffer);
            printf("data=%d ACK sent!\n", a[i]);
            sleep(1);
            write(P0pipe[1], "1", 1);
        }
        bubbleSort(a, n); //sort array
        FOR(i, n) {
            snprintf(buffer, sizeof(buffer), "%d", a[i]); //convert integer to string
            printf("P1 : Writing to P0pipe data=%s waiting for ACK\n", buffer);
            sleep(1);
            write(P0pipe[1], buffer, strlen(buffer)); //write integer to pipe
            read(P1pipe[0], & ACK, 1); //wait for ACKnowledgement
            printf("P1 : ACK received!\n\n");
            sleep(1);
        }
        close(P0pipe[0]);
        close(P0pipe[1]);
       
    }
	
    if (P1PID>0) {
        //printf("\nIn P1");  
        printf("\nSorted array:");
        FOR(i, n)
        printf("%d ", a[i]);
        sleep(1);
        write2file(a, n);
        printf("\nWriten to output.txt!");

    }
}
//MAIN################################################################
int main() {
    FILE * input = fopen("input.txt", "rt"); //doc file tu file data.txt
    char a[BUFFER_SIZE] = {0};
    char * a_ptr = 0;
    int i = 0, n = 0;
    int datafromfile[BUFFER_SIZE] = {0};

    //read data from file
    fgets(a, BUFFER_SIZE, input);
    a_ptr = strtok(a, " ");
    while (a_ptr != NULL) {
        datafromfile[i++] = atoi(a_ptr); // converting next token to 'int'
        a_ptr = strtok(NULL, " "); // reading next token
    }
    n = i;
    printf("Read from file done\n\n");
    sleep(1);
    
    //datafromfile[200]: array of number data in file
    //n: length of datafromfile[]
    
    byPipe(n, datafromfile);
    fclose(input);

}

