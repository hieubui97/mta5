﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Diagnostics;

namespace BTLTHDH
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Input_Open_Click(object sender, EventArgs e)
        {
            Process.Start("input.txt");
        }

        private void process_one_open_Click(object sender, EventArgs e)
        {
            Process one;
            one = Process.Start("Testing.exe");
        }

        private void process_two_open_Click(object sender, EventArgs e)
        {
            Process two;
            two = Process.Start("TestingClient.exe");
        }

        private void output_open_Click(object sender, EventArgs e)
        {
            Process.Start("output.txt");
        }
    }
}
