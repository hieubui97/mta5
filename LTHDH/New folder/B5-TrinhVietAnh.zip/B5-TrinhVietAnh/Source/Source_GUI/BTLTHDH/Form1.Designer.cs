﻿namespace BTLTHDH
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.panel3 = new System.Windows.Forms.Panel();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.panel4 = new System.Windows.Forms.Panel();
            this.output_open = new System.Windows.Forms.Button();
            this.process_two_open = new System.Windows.Forms.Button();
            this.process_one_open = new System.Windows.Forms.Button();
            this.input_open = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.panel1.Controls.Add(this.label4);
            this.panel1.Controls.Add(this.label3);
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Location = new System.Drawing.Point(0, -3);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(362, 684);
            this.panel1.TabIndex = 0;
            // 
            // label4
            // 
            this.label4.Font = new System.Drawing.Font("Segoe UI Semilight", 15F);
            this.label4.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label4.Location = new System.Drawing.Point(3, 420);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(353, 71);
            this.label4.TabIndex = 3;
            this.label4.Text = "MSV: 16150224";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label3
            // 
            this.label3.Font = new System.Drawing.Font("Segoe UI Semilight", 15F);
            this.label3.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label3.Location = new System.Drawing.Point(3, 316);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(353, 71);
            this.label3.TabIndex = 2;
            this.label3.Text = "Lớp: HTTT15";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label2
            // 
            this.label2.Font = new System.Drawing.Font("Segoe UI Semilight", 15F);
            this.label2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label2.Location = new System.Drawing.Point(3, 212);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(353, 71);
            this.label2.TabIndex = 1;
            this.label2.Text = "Họ tên: Trịnh Việt Anh";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.label1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.label1.Font = new System.Drawing.Font("Segoe UI Semilight", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.label1.Location = new System.Drawing.Point(3, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(353, 187);
            this.label1.TabIndex = 0;
            this.label1.Text = "Thông tin sinh viên";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label1.UseCompatibleTextRendering = true;
            // 
            // label5
            // 
            this.label5.Font = new System.Drawing.Font("Segoe UI Semilight", 37.75F);
            this.label5.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label5.Location = new System.Drawing.Point(46, 29);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(852, 133);
            this.label5.TabIndex = 0;
            this.label5.Text = "Ứng dụng";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // panel3
            // 
            this.panel3.Controls.Add(this.label8);
            this.panel3.Controls.Add(this.label7);
            this.panel3.Controls.Add(this.label6);
            this.panel3.Location = new System.Drawing.Point(0, 165);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(764, 519);
            this.panel3.TabIndex = 1;
            // 
            // label8
            // 
            this.label8.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label8.Location = new System.Drawing.Point(0, 377);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(761, 93);
            this.label8.TabIndex = 2;
            this.label8.Text = "Kết quả sẽ nằm trong file output";
            // 
            // label7
            // 
            this.label7.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label7.Location = new System.Drawing.Point(0, 212);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(761, 93);
            this.label7.TabIndex = 1;
            this.label7.Text = "Lần lượt chạy các process 1 và 2";
            // 
            // label6
            // 
            this.label6.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.label6.Location = new System.Drawing.Point(0, 47);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(761, 93);
            this.label6.TabIndex = 0;
            this.label6.Text = "Mở file input để thêm dữ liệu";
            // 
            // panel2
            // 
            this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Controls.Add(this.panel3);
            this.panel2.Controls.Add(this.label5);
            this.panel2.Font = new System.Drawing.Font("Segoe UI Semilight", 15F);
            this.panel2.ForeColor = System.Drawing.SystemColors.ControlLightLight;
            this.panel2.Location = new System.Drawing.Point(362, -3);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(904, 684);
            this.panel2.TabIndex = 1;
            // 
            // panel4
            // 
            this.panel4.Controls.Add(this.output_open);
            this.panel4.Controls.Add(this.process_two_open);
            this.panel4.Controls.Add(this.process_one_open);
            this.panel4.Controls.Add(this.input_open);
            this.panel4.Location = new System.Drawing.Point(762, 165);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(138, 519);
            this.panel4.TabIndex = 2;
            // 
            // output_open
            // 
            this.output_open.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.output_open.FlatAppearance.BorderSize = 0;
            this.output_open.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.output_open.Font = new System.Drawing.Font("Segoe UI Semilight", 13F);
            this.output_open.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.output_open.Location = new System.Drawing.Point(0, 407);
            this.output_open.Name = "output_open";
            this.output_open.Size = new System.Drawing.Size(141, 40);
            this.output_open.TabIndex = 3;
            this.output_open.Text = "Mở file output";
            this.output_open.UseVisualStyleBackColor = false;
            this.output_open.Click += new System.EventHandler(this.output_open_Click);
            // 
            // process_two_open
            // 
            this.process_two_open.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.process_two_open.FlatAppearance.BorderSize = 0;
            this.process_two_open.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.process_two_open.Font = new System.Drawing.Font("Segoe UI Semilight", 13F);
            this.process_two_open.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.process_two_open.Location = new System.Drawing.Point(0, 285);
            this.process_two_open.Name = "process_two_open";
            this.process_two_open.Size = new System.Drawing.Size(141, 40);
            this.process_two_open.TabIndex = 2;
            this.process_two_open.Text = "Chạy process 2";
            this.process_two_open.UseVisualStyleBackColor = false;
            this.process_two_open.Click += new System.EventHandler(this.process_two_open_Click);
            // 
            // process_one_open
            // 
            this.process_one_open.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.process_one_open.FlatAppearance.BorderSize = 0;
            this.process_one_open.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.process_one_open.Font = new System.Drawing.Font("Segoe UI Semilight", 13F);
            this.process_one_open.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.process_one_open.Location = new System.Drawing.Point(0, 150);
            this.process_one_open.Name = "process_one_open";
            this.process_one_open.Size = new System.Drawing.Size(141, 40);
            this.process_one_open.TabIndex = 1;
            this.process_one_open.Text = "Chạy process 1";
            this.process_one_open.UseVisualStyleBackColor = false;
            this.process_one_open.Click += new System.EventHandler(this.process_one_open_Click);
            // 
            // input_open
            // 
            this.input_open.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.input_open.FlatAppearance.BorderSize = 0;
            this.input_open.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.input_open.Font = new System.Drawing.Font("Segoe UI Semilight", 13F);
            this.input_open.ForeColor = System.Drawing.SystemColors.HighlightText;
            this.input_open.Location = new System.Drawing.Point(0, 43);
            this.input_open.Name = "input_open";
            this.input_open.Size = new System.Drawing.Size(141, 40);
            this.input_open.TabIndex = 0;
            this.input_open.Text = "Mở file input";
            this.input_open.UseVisualStyleBackColor = false;
            this.input_open.Click += new System.EventHandler(this.Input_Open_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1264, 681);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "Form1";
            this.panel1.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Button output_open;
        private System.Windows.Forms.Button process_two_open;
        private System.Windows.Forms.Button process_one_open;
        private System.Windows.Forms.Button input_open;
    }
}

