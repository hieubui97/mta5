﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;//sử dụng cho lớp DirectoryInfo và DriveInfo
//DirectoryInfo là một class đại diện cho một thư mục, nó cung cấp phương thức cho việc tạo, di chuyển, liệt kê các thư mục và các thư mục con. Class này không cho phép có class con.
//DirveInfo là một class, nó cung cấp các phương thức truy cập thông tin ổ cứng.

namespace My_Folder_Explorer
{
    public partial class Form1 : Form
    {
        //Khai báo biến toàn cục cho thư mục hiện tại
        DirectoryInfo curDir;
        public Form1()
        {
            InitializeComponent();
        }
        private void khoitaotreeView()
        {
            //thêm các icon vào treeView1
            treeView1.ImageList = new ImageList();
            treeView1.ImageList.Images.Add(new Icon("icons/ThisPC.ico"));
            treeView1.ImageList.Images.Add(new Icon("icons/drive.ico"));
            treeView1.ImageList.Images.Add(new Icon("icons/folder_close.ico"));
            treeView1.ImageList.Images.Add(new Icon("icons/folder_open.ico"));
            treeView1.ImageList.Images.Add(new Icon("icons/document.ico"));
            // Thêm ThisPC và các ổ đĩa
            TreeNode myComputerNode = new TreeNode("ThisPC");
            myComputerNode.Tag = "ThisPC";
            myComputerNode.ImageIndex = 0;
            myComputerNode.SelectedImageIndex = 0;
            treeView1.Nodes.Add(myComputerNode);
            // thêm các node ổ đĩa vào ThisPC node
            foreach (DriveInfo drive in DriveInfo.GetDrives())
            {
                TreeNode driveNode = new TreeNode(drive.Name);
                driveNode.Tag = drive.RootDirectory;
                driveNode.ImageIndex = 1;
                driveNode.SelectedImageIndex = 1;
                myComputerNode.Nodes.Add(driveNode);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            khoitaotreeView();
        }

        private void treeView1_AfterSelect(object sender, TreeViewEventArgs e)
        {
            // lấy node đang được chọn
            TreeNode selectedNode = treeView1.SelectedNode;

            try
            {
                if (selectedNode.Tag.GetType() == typeof(DirectoryInfo))
                {
                    // xóa danh sách các node đã có
                    selectedNode.Nodes.Clear();
                    // thêm các node thư mục con
                    DirectoryInfo dir = (DirectoryInfo)selectedNode.Tag;
                    foreach (DirectoryInfo subDir in dir.GetDirectories())
                    {
                        TreeNode dirNode = new TreeNode(subDir.Name);
                        dirNode.Tag = subDir;
                        dirNode.ImageIndex = 2;
                        dirNode.SelectedImageIndex = 3;
                        selectedNode.Nodes.Add(dirNode);
                    }
                    // hiển thị ở bên LisView
                    curDir = dir;
                    OpenDirectory();
                }
                // mở rộng node
                selectedNode.Expand();
            }
            catch
            {
                MessageBox.Show("không có CD!");
                return;
            }
        }

        private void OpenDirectory()
        {
            // thêm cột vào listview1
            listView1.Columns.Add("Name", 200, HorizontalAlignment.Left);
            listView1.Columns.Add("Size", 80, HorizontalAlignment.Right);
            listView1.Columns.Add("Type", 80, HorizontalAlignment.Left);
            listView1.Columns.Add("Date Modified", 230, HorizontalAlignment.Left);

            // hiển thị theo dạng chi tiết
            listView1.View = View.Details;

            // them danh sach hinh cho icon cua listview
            listView1.SmallImageList = new ImageList();
            listView1.SmallImageList.Images.Add(new Icon("icons/folder_open.ico"));
            listView1.SmallImageList.Images.Add(new Icon("icons/document.ico"));

            listView1.Items.Clear();
            foreach (DirectoryInfo subDir in curDir.GetDirectories())
            {
                ListViewItem lvi = listView1.Items.Add(subDir.Name);
                lvi.Tag = subDir;
                lvi.ImageIndex = 0;
                lvi.SubItems.Add("");
                lvi.SubItems.Add("Folder");
                lvi.SubItems.Add(subDir.LastWriteTime.ToString());
            }
            foreach (FileInfo file in curDir.GetFiles())
            {
                ListViewItem lvi = listView1.Items.Add(file.Name);
                lvi.Tag = file;
                lvi.ImageIndex = 1;
                lvi.SubItems.Add(file.Length.ToString());
                lvi.SubItems.Add("File");
                lvi.SubItems.Add(file.LastWriteTime.ToString());
            }
        }

        private void listView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                if (listView1.SelectedItems[0].Tag.GetType() == typeof(DirectoryInfo))
                {
                    curDir = (DirectoryInfo)listView1.SelectedItems[0].Tag;
                    OpenDirectory();
                }
                else
                {
                    FileInfo file = (FileInfo)listView1.SelectedItems[0].Tag;
                    System.Diagnostics.Process.Start(file.FullName);
                }
            }
            catch
            {
                MessageBox.Show("Không mở được file!");
                return;
            }
        }

        private void exitToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        //    private void iconSizeToolStripMenuItem_Click(object sender, EventArgs e)
        //    {
        //        listView1.View = View.LargeIcon;
        //        listView1.LargeImageList = new ImageList() { ImageSize = new Size(68, 68) };
        //        listView1.SmallImageList.Images.Add(new Icon("icons/folder_open.ico"));
        //        listView1.SmallImageList.Images.Add(new Icon("icons/document.ico"));
        //    }
        }
    }
