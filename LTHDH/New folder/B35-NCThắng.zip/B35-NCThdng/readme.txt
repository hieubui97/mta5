﻿Họ tên : Nguyễn Chiến Thắng
Ngày sinh : 11/03/1998
MSV : 16150064
Lớp : Khoa Học Máy Tính 15
Khoa : Công Nghệ Thông Tin