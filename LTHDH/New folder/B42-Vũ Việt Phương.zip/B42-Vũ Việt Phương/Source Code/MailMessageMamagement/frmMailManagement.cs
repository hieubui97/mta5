﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using S22.Imap;
using System.Net.Mail;
using System.Net;
namespace MailMessageMamagement
{
    public partial class frmMailManagement : Form
    {
        public string[] mailType = {"All", "Seen", "Unseen", "Answered", "Unanswered"};
        SearchCondition searchCondition = SearchCondition.All().And(SearchCondition.SentSince(new DateTime(2018, 10, 10)));
        IEnumerable<MailMessage> messages = null;
        ImapClient client = null;
        public frmMailManagement()
        {
            InitializeComponent();
        }


        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void frmMailManagement_Load(object sender, EventArgs e)
        {
            foreach(string type in mailType)
            {
                cboFunction.Items.Add(type);
            }
        }

        private void btnSeeAllMessages_Click(object sender, EventArgs e)
        {
            errorProvider.SetError(btnSeeAllMessages, "");
            if (txtUserName.Text == "" || txtPassword.Text == "")
            {
                errorProvider.SetError(btnSeeAllMessages, "Ban phai nhap tai khoan mat khau truoc.");
                return;
            }
            ReadAllMessages();
        }

        private void ReadAllMessages()
        {
            lvMessages.Items.Clear();
            IEnumerable<uint> mailIdentifiers = client.Search(searchCondition);
            messages = client.GetMessages(mailIdentifiers);
            foreach (MailMessage message in messages)
            {
                ListViewItem lvi = new ListViewItem(message.From.ToString());
                lvi.SubItems.Add(message.Subject.ToString());
                lvi.SubItems.Add(message.Body.ToString());
                lvi.Tag = message;
                lvMessages.Items.Add(lvi);
            }
        }

        private void lvMessages_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lvMessages.Items.Count == 0)
            {
                return;
            }
            try
            {
                ListViewItem lvi = lvMessages.SelectedItems[0];
                MailMessage mailMessage = lvi.Tag as MailMessage;
                lblFrom.Text = mailMessage.From.ToString();
                lblSubject.Text = mailMessage.Subject.ToString();
                txtBody.Text = mailMessage.Body.ToString();
            }
            catch { }
        }

        private void btnCompose_Click(object sender, EventArgs e)
        {
            errorProvider.SetError(btnCompose, "");
            if (txtUserName.Text == "" || txtPassword.Text == "")
            {
                errorProvider.SetError(btnCompose, "Ban phai nhap tai khoan mat khau truoc.");
                return;
            }
            frmComposeMail.username = txtUserName.Text;
            frmComposeMail.password = txtPassword.Text;
            frmComposeMail frmCM = new frmComposeMail();
            frmCM.ShowDialog();
        }

        private void cboFunction_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (cboFunction.SelectedItem.ToString() == "All")
            {
                searchCondition = SearchCondition.All().And(SearchCondition.SentSince(new DateTime(2018, 10, 10)));
            }
            else if (cboFunction.SelectedItem.ToString() == "Seen")
            {
                searchCondition = SearchCondition.Seen();
            }
            else if (cboFunction.SelectedItem.ToString() == "Unseen")
            {
                searchCondition = SearchCondition.Unseen();
            }
            else if (cboFunction.SelectedItem.ToString() == "Answered")
            {
                searchCondition = SearchCondition.Answered();
            }
            else
            {
                searchCondition = SearchCondition.Unanswered();
            }
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            try
            {
                client = new ImapClient("imap.gmail.com", 993, txtUserName.Text,
                txtPassword.Text, AuthMethod.Login, true);
                MessageBox.Show("Login successful");
            }
            catch(Exception ex)
            {
                MessageBox.Show("Tai khoan hoac mat khau khong chinh xac");
            }
        }
    }
}
