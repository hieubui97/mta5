﻿/* Nhóm 11 : Quản lý thu học phí 
			Lê Thị Oanh 
			Phan Sỹ Tuân 
			Dương Thị THu Phương 
			Nguyễn Thị Linh 
			Nguyễn Viết Hoàn*/
--Khởi tạo Database 
CREATE DATABASE HOCPHISV
GO 
USE HOCPHISV
GO
CREATE TABLE [dbo].NHANVIEN(
	[MaNV] NCHAR(10) PRIMARY KEY,
	[TenNV] NVARCHAR(100) NOT NULL,
	[ChucVu] NVARCHAR(200) NOT NULL,
	[SoDT] INT NOT NULL,
	[NgaySinh] DATE,
	[GioiTinh] NCHAR(5) CHECK ([GioiTinh] IN (N'NAM',N'NỮ')) ,
	--[MaBC] NCHAR(10) REFERENCES [dbo].BaoCao([MaBC])
)
-- begin
CREATE TABLE [dbo].KHOA(
	[MaKhoa] NCHAR(10) PRIMARY KEY NOT NULL,
	[TenKhoa] NVARCHAR(100) NOT NULL,
	[Dia_chi] NVARCHAR(200) NOT NULL,
	[SoDT] INT NOT NULL
)
CREATE TABLE [dbo].LOP(
	[MaLop] NCHAR(10) PRIMARY KEY NOT NULL,
	[TenLop] NVARCHAR(100) NOT NULL,
	[SoSV] INT,
	[MaKhoa] NCHAR(10) REFERENCES KHOA([MaKhoa])
)
CREATE TABLE [dbo].DOI_TUONG_MIEN_GIAM(
	[MaDoiTuong] NCHAR(10) PRIMARY KEY,
	[TenDoiTuong] NVARCHAR(100),
	[TyLeMienGiam] int NOT NULL
)
CREATE TABLE [dbo].SINHVIEN(
	[MaSV] NCHAR(10) PRIMARY KEY,
	[TenSV] NVARCHAR(100) NOT NULL,
	[GioiTinh] NCHAR(5) CHECK ([GioiTinh] IN (N'NAM',N'NỮ')) ,
	[Namsinh] DATE NOT NULL,
	[MaLop] NCHAR(10) REFERENCES LOP([MaLop]),
	[MaKhoa] NCHAR(10) REFERENCES KHOA([MaKhoa]),
	[MaDoiTuong] NCHAR(10) REFERENCES DOI_TUONG_MIEN_GIAM([MaDoiTuong])
)
-- end
CREATE TABLE [dbo].MUCTHU(
	[MucTC_HK] INT PRIMARY KEY,
	[SoTien] INT NOT NULL
)
CREATE TABLE [dbo].BIENLAI(
	[MaBL] NCHAR(10) PRIMARY KEY,
	[MaNV] NCHAR(10) REFERENCES NHANVIEN([MaNV]),
	[SoTien] MONEY NOT NULL,
	[NgayNop] DATE NOT NULL,
)
CREATE TABLE [dbo].SINHVIEN_MONHOC(
	[MaSV] NCHAR(10) REFERENCES SINHVIEN([MaSV]),
	[MaBL] NCHAR(10) REFERENCES BIENLAI([MaBL]),
	[SoLuongSV] INT,
	CONSTRAINT SV_MH PRIMARY KEY (MaSV,MaBL)
)
CREATE TABLE [dbo].LOPHOCPHAN(
	[MaHP] NCHAR(10) PRIMARY KEY,
	[TenHP] NVARCHAR(100) NOT NULL,
	[HocKy] INT NOT NULL,
	[MaMucThu] INT REFERENCES MUCTHU([MucTC_HK])
)
CREATE TABLE [dbo].CHI_TIET_BIENLAI(
	[MaBL] NCHAR(10) REFERENCES BIENLAI([MaBL]),
	[MaHP] NCHAR(10) REFERENCES LOPHOCPHAN([MaHP]),
	[Ngaynop] DATE,
	CONSTRAINT CT_BL PRIMARY KEY (MaBL,MaHP)
)


-- Select
SELECT * FROM NHANVIEN
SELECT * FROM KHOA
SELECT * FROM LOP
SELECT * FROM SINHVIEN
SELECT * FROM MUCTHU
SELECT * FROM BIENLAI
SELECT * FROM CHI_TIET_BIENLAI
SELECT * FROM SINHVIEN_MONHOC
SELECT * FROM LOPHOCPHAN
SELECT * FROM DOI_TUONG_MIEN_GIAM


--Insert giá trị cho các bản
-- Nhân viên
INSERT INTO NHANVIEN values ('NV1',N'Nguyễn Hoàng Ngân',N'Nhân Viên','0973229229','1/1/1990',N'Nam')
INSERT INTO NHANVIEN values ('NV2',N'Đào Minh Tuấn',N'Phó Phòng','0982228228','1/1/1990',N'Nam')
INSERT INTO NHANVIEN values ('NV3',N'Nguyễn Văn Phú',N'Trưởng Phòng','0987774774','1/1/1990',N'Nam')
INSERT INTO NHANVIEN values ('NV4',N'Nguyễn Khắc Việt',N'Thực Tập','0922899899','1/1/1990',N'Nam')
INSERT INTO NHANVIEN values ('NV5',N'Hà Phương Thảo',N'Vệ Sinh','0988228228','1/1/1990',N'NỮ')
INSERT INTO NHANVIEN values ('NV6',N'Bùi Khắc Tuấn',N'Chuyển Phát','0973229229','1/1/1990',N'Nam')
INSERT INTO NHANVIEN values ('NV7',N'Bùi Thị Linh',N'Chuyển Phát Nhanh','0973229229','1/1/1992',N'NỮ')
INSERT INTO NHANVIEN values ('NV8',N'Nguyễn Thị Linh',N'Biên Tập','0973299299','1/1/1990',N'NỮ')
INSERT INTO NHANVIEN values ('NV9',N'Phạm Thị Trang',N'Đánh Máy','0973288288','1/1/1990',N'NỮ')
INSERT INTO NHANVIEN values ('NV10',N'Nguyễn Thùy Linh',N'Phô Tô','0987654321','1/1/1990',N'NỮ')
INSERT INTO NHANVIEN values ('NV11',N'Trần Văn Xuân',N'Viết Hóa Đơn','0912345678','1/1/1990',N'Nam')
INSERT INTO NHANVIEN values ('NV12',N'Nguyễn Viết Xuân',N'Tiếp Tân','0982888888','1/1/1990',N'Nam')
INSERT INTO NHANVIEN values ('NV13',N'Phạm Xuân Đông',N'Thư ký ','0969996996','1/1/1990',N'Nam')
INSERT INTO NHANVIEN values ('NV14',N'Lê Thanh Hải',N'Lễ Tân','0947774774','1/1/1990',N'Nam')
INSERT INTO NHANVIEN values ('NV15',N'Lê Văn Tiến',N'Trực điện thoại','0989889889','1/1/1990',N'Nam')
INSERT INTO NHANVIEN values ('NV16',N'Dương Văn Nam',N'Tư vấn ','01677227102','1/1/1990',N'Nam')
INSERT INTO NHANVIEN values ('NV17',N'Hà Sơn Bình',N'Chăm sóc khách hàng','01688228102','1/1/1990',N'Nam')
INSERT INTO NHANVIEN values ('NV18',N'Trần Thị Hảo ',N'kế hoặch','01699229102','1/1/1990',N'NỮ')
INSERT INTO NHANVIEN values ('NV19',N'Trần Trọng Ninh',N'Kinh doanh','01655225102','1/1/1990',N'Nam')
INSERT INTO NHANVIEN values ('NV20',N'Lê Văn Tuyển',N'Đầu tư','01633223102','1/1/1990',N'Nam')

--Khoa
INSERT INTO KHOA values ('K01',N'Khoa CNTT','H1P101','041256')
INSERT INTO KHOA values ('K02',N'Khoa Hóa Lý kỹ thuật','H1P201','041256')
INSERT INTO KHOA values ('K03',N'Khoa Vũ Khí','H1P301','041256')
INSERT INTO KHOA values ('K04',N'Khoa Cơ Khí ','H1P401','041256')
INSERT INTO KHOA values ('K05',N'Khoa Điện tử viễn thông','H1P501','041256')
INSERT INTO KHOA values ('K06',N'Khoa Khoa Học Máy Tính','H1P601','041256')
INSERT INTO KHOA values ('K07',N'Khoa Tổ Chức Liên Lạc','H1P701','041256')
INSERT INTO KHOA values ('K08',N'Khoa Công Nghệ Phần Mềm','H1P801','041256')
INSERT INTO KHOA values ('K09',N'Khoa Hệ Thống Thông Tin','H1P901','041256')
INSERT INTO KHOA values ('K010',N'Khoa Đào Tạo Sau Đại Học','H1P102','041256')
INSERT INTO KHOA values ('K011',N'Khoa Tào Tạo Du Học','H1P103','041256')
INSERT INTO KHOA values ('K012',N'Khoa Quốc Tế ','H1P202','041256')
INSERT INTO KHOA values ('K013',N'Khoa An Toàn Thông Tin','H1P302','041256')
INSERT INTO KHOA values ('K014',N'Khoa Công Nghệ Thực Phẩm','H1P402','041256')
INSERT INTO KHOA values ('K015',N'Khoa Công Nghệ Dệt May','H1P502','041256')
INSERT INTO KHOA values ('K016',N'Khoa Liên Kết Đào Tạo','H1P602','041256')
INSERT INTO KHOA values ('K017',N'Trung Tâm Tiếng Anh','H1P702','041256')
INSERT INTO KHOA values ('K018',N'Khoa Công Nghệ Web','H1P802','041256')
INSERT INTO KHOA values ('K019',N'Khoa Triết Học','H1P902','041256')
INSERT INTO KHOA values ('K020',N'Khoa Tự Động Hóa','H1P1001','041256')

--Lớp
INSERT INTO LOP values ('L01','CNTT14',97,'K01')
INSERT INTO LOP values ('L02','DĐT14',99,'K03')
INSERT INTO LOP values ('L03','ĐTVT14',87,'K03')
INSERT INTO LOP values ('L04','CNHH14',67,'K04')
INSERT INTO LOP values ('L05','KHMT14',57,'K01')
INSERT INTO LOP values ('L06','KTPM14',78,'K01')
INSERT INTO LOP values ('L07','HTTT14',50,'K01')
INSERT INTO LOP values ('L08','CĐT14',100,'K03')
INSERT INTO LOP values ('L09','CNNTT13',60,'K01')
INSERT INTO LOP values ('L010','ĐT13',66,'K03')
INSERT INTO LOP values ('L011','CĐT13',69,'K03')
INSERT INTO LOP values ('L012','ĐTVT13',55,'K03')
INSERT INTO LOP values ('L013','KHMT13',40,'K01')
INSERT INTO LOP values ('L014','HTTT13',43,'K01')
INSERT INTO LOP values ('L015','CNHH13',66,'K04')
INSERT INTO LOP values ('L016','KTPM13',77,'K01')
INSERT INTO LOP values ('L017','CNHH12',88,'K04')
INSERT INTO LOP values ('L018',N'Tin HỌC 11_A',97,'K01')
INSERT INTO LOP values ('L019',N'Tin học 11_B',97,'K01')
INSERT INTO LOP values ('L020',N'Tin Học 11_C',97,'K01')

-- Đối tượng miễn giảm
INSERT INTO DOI_TUONG_MIEN_GIAM values ('DT01',N'Hộ nghèo',20)
INSERT INTO DOI_TUONG_MIEN_GIAM values ('DT02',N'Thương Binh',30)
INSERT INTO DOI_TUONG_MIEN_GIAM values ('DT03',N'Cả Thương Binh và Hộ nghèo',30)

--Sinh viên
SELECT * FROM SINHVIEN
INSERT INTO SINHVIEN(MaSV,TenSV,GioiTinh,Namsinh,MaLop,MaKhoa,MaDoiTuong) values	('SV1',N'Lê Thị Oanh',N'NỮ','08/23/1996','L01','K01','DT01')
INSERT INTO SINHVIEN(MaSV,TenSV,GioiTinh,Namsinh,MaLop,MaKhoa,MaDoiTuong) values ('SV2',N'Nguyễn Văn A',N'Nam','01/23/1997','L03','K02','DT02')
INSERT INTO SINHVIEN(MaSV,TenSV,GioiTinh,Namsinh,MaLop,MaKhoa,MaDoiTuong) values ('SV3',N'Nguyễn Văn B',N'Nam','02/23/1993','L04','K03','DT03')
INSERT INTO SINHVIEN(MaSV,TenSV,GioiTinh,Namsinh,MaLop,MaKhoa,MaDoiTuong) values ('SV4',N'Lê Thị C',N'NỮ','03/30/1998','L01','K04','DT03')
INSERT INTO SINHVIEN(MaSV,TenSV,GioiTinh,Namsinh,MaLop,MaKhoa,MaDoiTuong) values ('SV5',N'Nguyễn Văn An',N'Nam','04/27/1991','L03','K05','DT01')
INSERT INTO SINHVIEN(MaSV,TenSV,GioiTinh,Namsinh,MaLop,MaKhoa,MaDoiTuong) values ('SV6',N'Nguyễn Văn D',N'Nam','05/13/1992','L04','K06','DT02')
INSERT INTO SINHVIEN(MaSV,TenSV,GioiTinh,Namsinh,MaLop,MaKhoa,MaDoiTuong) values ('SV7',N'Nguyễn Văn E',N'Nam','06/18/1994','L05','K07','DT01')
INSERT INTO SINHVIEN(MaSV,TenSV,GioiTinh,Namsinh,MaLop,MaKhoa,MaDoiTuong) values ('SV8',N'Lê Thị B',N'NỮ','07/29/1995','L06','K08','DT02')
INSERT INTO SINHVIEN(MaSV,TenSV,GioiTinh,Namsinh,MaLop,MaKhoa,MaDoiTuong) values ('SV9',N'Lê Thị A',N'NỮ','09/23/1995','L07','K09','DT01')
INSERT INTO SINHVIEN(MaSV,TenSV,GioiTinh,Namsinh,MaLop,MaKhoa) values ('SV10',N'Nguyễn Văn F',N'Nam','08/12/1991','L08','K010')
INSERT INTO SINHVIEN(MaSV,TenSV,GioiTinh,Namsinh,MaLop,MaKhoa) values ('SV11',N'Lê Thị D',N'NỮ','01/13/1990','L09','K011')
INSERT INTO SINHVIEN(MaSV,TenSV,GioiTinh,Namsinh,MaLop,MaKhoa) values ('SV12',N'Nguyễn Văn G',N'nam','08/14/1991','L010','K012')
INSERT INTO SINHVIEN(MaSV,TenSV,GioiTinh,Namsinh,MaLop,MaKhoa) values ('SV13',N'Nguyễn Văn H',N'nam','05/15/1990','L06','K013')
INSERT INTO SINHVIEN(MaSV,TenSV,GioiTinh,Namsinh,MaLop,MaKhoa) values ('SV14',N'Lê Thị V',N'NỮ','02/16/1993','L03','K014')
INSERT INTO SINHVIEN(MaSV,TenSV,GioiTinh,Namsinh,MaLop,MaKhoa) values ('SV15',N'Nguyễn Văn X',N'nam','08/17/1992','L011','K015')
INSERT INTO SINHVIEN(MaSV,TenSV,GioiTinh,Namsinh,MaLop,MaKhoa) values ('SV16',N'Lê Thị Y',N'NỮ','11/20/1995','L012','K016')
INSERT INTO SINHVIEN(MaSV,TenSV,GioiTinh,Namsinh,MaLop,MaKhoa) values ('SV17',N'Lê Thị XX',N'NỮ','12/21/1996','L013','K017')
INSERT INTO SINHVIEN(MaSV,TenSV,GioiTinh,Namsinh,MaLop,MaKhoa,MaDoiTuong) values ('SV18',N'Nguyễn Văn M',N'nam','08/29/1997','L014','K018','DT03')
INSERT INTO SINHVIEN(MaSV,TenSV,GioiTinh,Namsinh,MaLop,MaKhoa) values ('SV19',N'Lê Thị AAA',N'NỮ','07/10/1993','L015','K019')
INSERT INTO SINHVIEN(MaSV,TenSV,GioiTinh,Namsinh,MaLop,MaKhoa) values ('SV20',N'Nguyễn Văn JJJ',N'nam','07/06/1990','L016','K020')

--Mức thu
INSERT INTO MucThu values ('250','1100000')
INSERT INTO MucThu values ('255','2200000')
INSERT INTO MucThu values ('251','3300000')
INSERT INTO MucThu values ('350','4400000')
INSERT INTO MucThu values ('252','3200000')
INSERT INTO MucThu values ('253','3100000')
INSERT INTO MucThu values ('254','3300000')
INSERT INTO MucThu values ('256','1800000')
INSERT INTO MucThu values ('257','1900000')
INSERT INTO MucThu values ('258','2000000')
INSERT INTO MucThu values ('259','3000000')
INSERT INTO MucThu values ('351','4000000')
INSERT INTO MucThu values ('352','2900000')
INSERT INTO MucThu values ('353','3700000')
INSERT INTO MucThu values ('354','4400000')
INSERT INTO MucThu values ('355','3500000')
INSERT INTO MucThu values ('356','4100000')
INSERT INTO MucThu values ('357','3600000')
INSERT INTO MucThu values ('358','4800000')
INSERT INTO MucThu values ('359','4700000')

--Biên lai
INSERT INTO BIENLAI values ('BL1','NV1','2200000','09/23/2017')
INSERT INTO BIENLAI values ('BL2','NV2','2500000','09/23/2017')
INSERT INTO BIENLAI values ('BL3','NV3','3300000','09/23/2017')
INSERT INTO BIENLAI values ('BL4','NV4','4400000','09/23/2017')
INSERT INTO BIENLAI values ('BL5','NV5','3200000','09/23/2017')
INSERT INTO BIENLAI values ('BL6','NV6','3100000','09/23/2017')
INSERT INTO BIENLAI values ('BL7','NV8','3300000','09/23/2017')
INSERT INTO BIENLAI values ('BL8','NV8','1800000','09/23/2017')
INSERT INTO BIENLAI values ('BL9','NV9','1900000','09/23/2017')
INSERT INTO BIENLAI values ('BL10','NV10','2000000','09/23/2017')
INSERT INTO BIENLAI values ('BL11','NV11','3000000','09/23/2017')
INSERT INTO BIENLAI values ('BL12','NV12','4000000','09/23/2017')
INSERT INTO BIENLAI values ('BL13','NV13','3500000','09/23/2017')
INSERT INTO BIENLAI values ('BL14','NV14','4100000','09/23/2017')
INSERT INTO BIENLAI values ('BL15','NV15','3600000','09/23/2017')
INSERT INTO BIENLAI values ('BL16','NV16','4800000','09/23/2017')
INSERT INTO BIENLAI values ('BL17','NV17','3600000','09/23/2017')
INSERT INTO BIENLAI values ('BL18','NV18','4800000','09/23/2017')
INSERT INTO BIENLAI values ('BL19','NV19','3500000','09/23/2017')
INSERT INTO BIENLAI values ('BL20','NV20','4100000','09/23/2017')

-- Lớp học phần
SELECT * FROM LOPHOCPHAN
INSERT INTO LOPHOCPHAN values ('HP1',N'Giải Tích','1','250')
INSERT INTO LOPHOCPHAN values ('HP2',N'Đại số tuyến tính','1','251')
INSERT INTO LOPHOCPHAN values ('HP3',N'Ngôn ngữ lập trình 1','4','252')
INSERT INTO LOPHOCPHAN values ('HP4',N'Ngôn ngữ lập trình 2','5','253')
INSERT INTO LOPHOCPHAN values ('HP5',N'Phân tích thiết kế giải thuật','5','254')
INSERT INTO LOPHOCPHAN values ('HP6',N'Mạng máy tính','4','255')
INSERT INTO LOPHOCPHAN values ('HP7',N'Lập trình hướng đối tượng','4','256')
INSERT INTO LOPHOCPHAN values ('HP8',N'Cầu lông','3','257')
INSERT INTO LOPHOCPHAN values ('HP9',N'Bóng chuyền','4','258')
INSERT INTO LOPHOCPHAN values ('HP10',N'Toán rời rạc','3','259')
INSERT INTO LOPHOCPHAN values ('HP11',N'Vật lý','2','350')
INSERT INTO LOPHOCPHAN values ('HP12',N'Quốc phòng','1','351')
INSERT INTO LOPHOCPHAN values ('HP13',N'Trết 1','1','352')
INSERT INTO LOPHOCPHAN values ('HP14',N'cơ sở dữ liệu','5','353')
INSERT INTO LOPHOCPHAN values ('HP15',N'Đảm bảo an toàn thông tin','5','354')
INSERT INTO LOPHOCPHAN values ('HP16',N'Lý thuyết hệ điều hành','5','355')
INSERT INTO LOPHOCPHAN values ('HP17',N'Mạng viễn thông','4','356')
INSERT INTO LOPHOCPHAN values ('HP18',N'Toán chuyên đề ','5','357')
INSERT INTO LOPHOCPHAN values ('HP19',N'Cấu trúc máy tính','3','358')
INSERT INTO LOPHOCPHAN values ('HP20',N'Xác suất thống kê','3','359')

--Chi tiết Bill
INSERT INTO CHI_TIET_BIENLAI values ('BL1','HP1','09/12/2017')
INSERT INTO CHI_TIET_BIENLAI values ('BL2','HP2','08/11/2017')
INSERT INTO CHI_TIET_BIENLAI values ('BL3','HP3','07/23/2017')
INSERT INTO CHI_TIET_BIENLAI values ('BL4','HP4','06/30/2017')
INSERT INTO CHI_TIET_BIENLAI values ('BL5','HP5','09/30/2017')
INSERT INTO CHI_TIET_BIENLAI values ('BL6','HP6','01/23/2017')
INSERT INTO CHI_TIET_BIENLAI values ('BL7','HP7','02/20/2017')
INSERT INTO CHI_TIET_BIENLAI values ('BL8','HP8','09/29/2017')
INSERT INTO CHI_TIET_BIENLAI values ('BL9','HP9','11/28/2017')
INSERT INTO CHI_TIET_BIENLAI values ('BL10','HP10','12/25/2017')
INSERT INTO CHI_TIET_BIENLAI values ('BL11','HP11','10/22/2017')
INSERT INTO CHI_TIET_BIENLAI values ('BL12','HP12','09/23/2017')
INSERT INTO CHI_TIET_BIENLAI values ('BL13','HP13','01/26/2017')
INSERT INTO CHI_TIET_BIENLAI values ('BL14','HP14','05/27/2017')
INSERT INTO CHI_TIET_BIENLAI values ('BL15','HP15','05/28/2017')
INSERT INTO CHI_TIET_BIENLAI values ('BL16','HP16','06/01/2017')
INSERT INTO CHI_TIET_BIENLAI values ('BL17','HP17','07/12/2017')
INSERT INTO CHI_TIET_BIENLAI values ('BL18','HP18','08/17/2017')
INSERT INTO CHI_TIET_BIENLAI values ('BL19','HP19','11/19/2017')
INSERT INTO CHI_TIET_BIENLAI values ('BL20','HP20','12/20/2017')

--SV_Môn học
INSERT INTO SINHVIEN_MONHOC values ('SV1','BL1','45')
INSERT INTO SINHVIEN_MONHOC values ('SV2','BL2','50')
INSERT INTO SINHVIEN_MONHOC values ('SV3','BL3','55')
INSERT INTO SINHVIEN_MONHOC values ('SV4','BL4','60')
INSERT INTO SINHVIEN_MONHOC values ('SV5','BL5','65')
INSERT INTO SINHVIEN_MONHOC values ('SV6','BL6','70')
INSERT INTO SINHVIEN_MONHOC values ('SV7','BL7','75')
INSERT INTO SINHVIEN_MONHOC values ('SV8','BL8','80')
INSERT INTO SINHVIEN_MONHOC values ('SV9','BL9','85')
INSERT INTO SINHVIEN_MONHOC values ('SV10','BL10','90')
INSERT INTO SINHVIEN_MONHOC values ('SV11','BL11','95')
INSERT INTO SINHVIEN_MONHOC values ('SV12','BL12','100')
INSERT INTO SINHVIEN_MONHOC values ('SV13','BL13','40')
INSERT INTO SINHVIEN_MONHOC values ('SV14','BL14','35')
INSERT INTO SINHVIEN_MONHOC values ('SV15','BL15','30')
INSERT INTO SINHVIEN_MONHOC values ('SV16','BL16','25')

INSERT INTO SINHVIEN_MONHOC values ('SV17','BL17','20')
INSERT INTO SINHVIEN_MONHOC values ('SV18','BL18','15')
INSERT INTO SINHVIEN_MONHOC values ('SV19','BL19','10')
INSERT INTO SINHVIEN_MONHOC values ('SV20','BL20','5')

--Đưa ra MaSV, HoTen, GT của những sinh viên thuộc lớp có số sinh viên > 70
SELECT MaSV, sv.TenSV, sv.GioiTinh
FROM SINHVIEN SV, LOP L
WHERE SoSV > 70 AND SV.MaLop=L.MaLop 

--Đưa ra MaSV, HoTen của những sinh viên thuộc lớp có tên là CNTT14
SELECT MaSV, TenSV
FROM SINHVIEN
WHERE EXISTS
           (SELECT *
		   FROM LOP L, Sinhvien SV
		   WHERE L.MaLop = SV.MaLop AND TenLop='CNTT14' )

--Đưa ra những khoa có từ 4 lớp trở lên
SELECT K.MaKhoa, TenKhoa, COUNT(MaLop) as SL
FROM KHOA K, LOP L
WHERE K.MaKhoa= L.MaKhoa
GROUP BY K.MaKhoa,TenKhoa
HAVING COUNT(MaLop)>=4

--Đưa ra Mã nhân viên, họ tên nhân viên và mã biên lai của những nhân viên viết cùng một biên lai
SELECT NV.MaNV,TenNV
FROM NHANVIEN NV, (SELECT MaNV,MaBL FROM BIENLAI) AS BL
WHERE NV.MaNV= BL.MaNV

--Đưa ra mã học phần , tên học phần tương ứng của nhưng học phần có cùng 1 mã mức thu
SELECT MaHP, TenHP
FROM LOPHOCPHAN LHP, MUCTHU MT
WHERE MT.MucTC_HK= LHP.MaMucThu

-- Đưa ra mã biên lai, ngày nộp của những biên lai có mã học phần là 'HP10'
SELECT MaBL, NgayNop
FROM BIENLAI
WHERE exists (SELECT MaHP
              FROM CHI_TIET_BIENLAI
			  WHERE MaHP='HP10' )
             
-- Đưa ra khoa có đông lớp nhất
SELECT TOP 1 WITH TIES MaKhoa, COUNT (MaLop) as SL
FROM LOP
GROUP BY MaKhoa
ORDER BY SL DESC

-- Đưa ra mã sinh viên, họ tên , tên lớp tương ứng của sinh viên và cả những sinh viên chưa thuộc lớp nào
SELECT MaSV,TenSV, TenLop, L.MaLop
FROM LOP L LEFT JOIN SINHVIEN SV
ON L.MaLop=SV.MaLop

--Đưa ra MaSV, TenSV của những sinh vien là nữ thuộc đối tượng 'DT01'
SELECT MaSV,TenSV
FROM SINHVIEN
WHERE GioiTinh= N'NỮ' AND MaDoiTuong='DT01'

--Đưa ra mã mức thu và số tiền theo thứ tự giảm dần
SELECT SoTien,MucTC_HK
FROM MUCTHU
ORDER BY SoTien DESC , MucTC_HK

--Đưa ra mã HP, Tên HP của những học phần có SoTien là 4400000
SELECT MaHP, TenHP
FROM LOPHOCPHAN
WHERE MaMucThu IN(                                 ----------LONG PHAN CAP
                   SELECT MucTC_HK
				   FROM MUCTHU
				   WHERE SoTien='4400000'

-- Đưa ra mã sinh viên, tên sinh viên và giới tính của những sinh viên thuộc đối tượng thương binh
SELECT MaSV, TenSV, GioiTinh
FROM SINHVIEN 
WHERE EXISTS(
               SELECT*                  -----------LONG TUONG QUAN
			   FROM DOI_TUONG_MIEN_GIAM
			   WHERE MaDoiTuong= SINHVIEN.MaDoiTuong AND TenDoiTuong=N'Thương Binh'
			   )

--Đưa ra Mã sinh viên, tên sinh viên và tên đối tượng miễn giảm tương ứng của sinh viên đó
SELECT MaSV, TenSV,TenDoiTuong
FROM SINHVIEN SV, (SELECT MaDoiTuong, TenDoiTuong
                  FROM DOI_TUONG_MIEN_GIAM) DTMG
WHERE SV.MaDoiTuong=DTMG.MaDoiTuong

--Đưa ra mã biên lai, số tiền,ngày nộp và tên của những  nhân viên có giới tính là nữ viết biên lai đó
SELECT MaBL, SoTien, NgayNop, TenNV
FROM BIENLAI BL, (SELECT MaNV, TenNV
                  FROM NHANVIEN
				  WHERE GioiTinh=N'NỮ') NV
WHERE BL.MaNV=NV.MaNV

--Đếm số biên lai theo từng nhân viên
SELECT COUNT(MaBL)AS SOLUONGBL, NV.MaNV, TenNV
FROM BIENLAI BL, NHANVIEN NV
WHERE BL.MaNV=NV.MaNV
GROUP BY NV.MaNV,TenNV

--
--LẬP TRÌNH T-SQL

--Tao thu thuc them doi tuong mien giam madt, tendt, ty mien giam
CREATE PROC ThemDOI_TUONG_MIEN_GIAM(@MaDT NCHAR(10),@TenDT NVARCHAR(100),@TLMG INT)
AS
BEGIN
INSERT INTO DOI_TUONG_MIEN_GIAM(MaDoiTuong,TenDoiTuong,TyLeMienGiam)
VALUES (@MaDT,@TenDT,@TLMG)
END
--THUC THI
EXEC ThemDOI_TUONG_MIEN_GIAM '10',N'Mồ Côi',50--thuc thi thu tuc
SELECT*FROM DOI_TUONG_MIEN_GIAM

--Tao thu tuc xem thong tin cua mot sinh vien(truy vấn )
CREATE PROC XEMTTSV(@MaSV NCHAR(10))
AS
BEGIN
SELECT * FROM SINHVIEN where MaSV=@MaSV
END
	--TEST
	 EXEC XEMTTSV'SV2'
-- Tạo thủ xem những mã học phần có mã mức thu lớn hơn  300
alter  proc xemMaMT(@MaMT nchar (10))
as 
begin 
select MaMucThu
from LOPHOCPHAN
where MaMucThu>@MaMT
end
--TEST
 xemMaMT 300


CREATE TRIGGER THEMSINHVIEN ON SINHVIEN AFTER INSERT
AS
BEGIN
      DECLARE @MaLop NCHAR(10)
	  SELECT @MaLop=@MaLop
	  FROM INSERTED
	  UPDATE LOP
	  SET SoSV=SoSV+1
	  WHERE MaLop=@MaLop
END



--Tạo trigger để khi thêm một học phần thì thông báo mã học phần vừa được thêm
CREATE TRIGGER THEMHP ON LOPHOCPHAN FOR INSERT
AS
      DECLARE @Ma NCHAR(10)
BEGIN
      SELECT @Ma=MaHP FROM INSERTED
	  PRINT' Ma hoc Phan vua them la'+@ma
END
-- THUC THI 
      INSERT INTO LOPHOCPHAN VALUES('HP21',N'Điện Tử Số','6','250')

--Tạo trigger khi xóa một sinh viên thì thông báo ra mã sinh viên vừa xóa
CREATE TRIGGER XOASV ON SINHVIEN INSTEAD OF DELETE
AS 
   DECLARE @MaSV NCHAR(10)
BEGIN
   SELECT  @MaSV
   DELETE SINHVIEN_MONHOC WHERE MaSV=@MaSV
   DELETE SINHVIEN WHERE MaSV=@MaSV
   PRINT' Ma sinh vien vua xoa la'+@MaSV
END
--thuc thi
 DELETE FROM SINHVIEN
 WHERE MaKhoa= 'K01'

--Tạo hàm có một tham số là @MaKhoa NCHAR(10), thực hiện thống kê số lớp theo mã khoa nhập vào, nếu giá trị biến @MaKhoa nhập vào là kí tự trống hoặc NULL thì thống kê lớp theo từng khoa
CREATE FUNCTION Func_TongL(@MaLop NCHAR(10))
  RETURNS @BangThongKe TABLE
   (
     MaKhoa NCHAR(10),
	 TongSoLop int
   )AS
BEGIN
  IF(@MaKhoa is NULL) OR(@MaKhoa=' ')
     INSERT INTO @BangThongKe
     SELECT MaKhoa, COUNT(MaLop)
	 FROM LOP
	 GROUP BY MaKhoa
  ELSE
     INSERT INTO @BangThongKe
	 SELECT MaKhoa, COUNT(MaLop)
	 FROM LOP
	 WHERE MaKhoa=@MaKhoa
	 GROUP BY MaKhoa
RETURN
END
      --TEST 
	       SELECT * FROM dbo.func_TongL('K1')
