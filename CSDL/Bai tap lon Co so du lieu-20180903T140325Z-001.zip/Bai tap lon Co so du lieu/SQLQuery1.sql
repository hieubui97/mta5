﻿USE HOCPHISV
GO
---CAU 2
--2.1 --Đưa ra Mã nhân viên, họ tên nhân viên và mã biên lai của những nhân viên viết cùng một biên lai
SELECT NV.MaNV,TenNV
FROM NHANVIEN NV, (SELECT MaNV,MaBL FROM BIENLAI) AS BL
WHERE NV.MaNV= BL.MaNV

2-2--Đưa ra mã học phần, tên học phần của những học phần có SoTien là 4400000
SELECT MaHP, TenHP 
FROM LOPHOCPHAN
WHERE MaMucThu IN(                               
                   SELECT MucTC_HK
				   FROM MUCTHU
				   WHERE SoTien='4400000'
-- Đưa ra mã sinh viên, tên sinh viên và giới tính của những sinh viên thuộc đối tượng thương binh
SELECT MaSV, TenSV, GioiTinh
FROM SINHVIEN 
WHERE EXISTS(
               SELECT*                
			   FROM DOI_TUONG_MIEN_GIAM
			   WHERE MaDoiTuong= SINHVIEN.MaDoiTuong AND TenDoiTuong=N'Thương Binh'
			   )

2-3
-- ĐƯA RA MÃ HỌC PHẦN, TÊN HỌC PHẦN CỦA NHƯNG HỌC PHẦN CÓ MÃ MỨC THU NHỎ NHẤT
SELECT MaHP, TenHP, MIN(MaMucThu)
FROM LOPHOCPHAN

 --Đếm số biên lai theo từng nhân viên
SELECT COUNT(MaBL)AS SOLUONGBL, NV.MaNV, TenNV
FROM BIENLAI BL, NHANVIEN NV
WHERE BL.MaNV=NV.MaNV
GROUP BY NV.MaNV,TenNV

---Đưa ra những khoa có từ 4 lớp trở lên
SELECT K.MaKhoa, TenKhoa, COUNT(MaLop) as SL
FROM KHOA K, LOP L
WHERE K.MaKhoa= L.MaKhoa
GROUP BY K.MaKhoa,TenKhoa
HAVING COUNT(MaLop)>=4

CAU 3
3.1--Tao thu thuc them doi tuong mien giam madt, tendt, ty mien giam
ALTER PROC ThemDOI_TUONG_MIEN_GIAM(@MaDT NCHAR(10),@TenDT NVARCHAR(100),@TLMG INT)
AS
BEGIN
INSERT INTO DOI_TUONG_MIEN_GIAM(MaDoiTuong,TenDoiTuong,TyLeMienGiam)
VALUES (@MaDT,@TenDT,@TLMG)
END
--THUC THI
EXEC ThemDOI_TUONG_MIEN_GIAM 'DT10',N'KHUYẾT TẬT','40' --thuc thi thu tuc
SELECT*FROM DOI_TUONG_MIEN_GIAM

3.2 -- THỦ TỤC TRUY VẤN, THỐNG KÊ:
alter proc xemttSV(@MaSV nchar (10))
as 
begin 
select * from SINHVIEN where MaSV=@MaSV
end
	--TEST
	xemttSV 'sv1'

--tao thu tục xem thông tin của một sinh viên
3.3 --thủ tục truy vấn t


CÂU 1
1.13
--Thêm một học phần vào bảng học phần
INSERT INTO LOPHOCPHAN VALUES('HP22',N'Toán Chuyên Đề','3','250')

--Tăng mã mức thu thêm 

-- Hãy xóa đi những sinh viên có mã đối tượng là 'DT01'
DELETE FROM SINHVIEN
WHERE MaDoiTuong='DT01'

1.15 -- Với những học phần có mã học phần là HP1 hãy thay đổi học kỳ thành học kỳ 3
UPDATE LOPHOCPHAN
SET HocKy='3'
WHERE MaHP='HP1'

1.16
-- Với những biên lai có mã biên lai là BL20  hãy thay đổi mã nhân viên thành SV21
UPDATE BIENLAI
SET MaNV='NV1'
WHERE MaBL='BL20' 

1.14
 CÁC BẢNG ĐƯỢC TẠO THUỘC DẠNG CHUẨN NÀO
 BẢNG NHANVIEN

